Supplementary Material

This supplementary material consists of 2 (two) documents.

The first, titled "Gesture Types Definitions Table" contains a table with the definitions for the 26 gesture types detected in the data and their classification into the manual or whole-body category. The definitions were adapted from Hobaiter & Byrne (2011) and Nishida (2010). 


The second, titled "Figures", contains the two figures cited in the main text. Figure 1 shows the gesture types data pattern when testing for Zipf's law of brevity, while Figure 2 depicts the gesture sequence data pattern when testing for Menzerath's law. 

