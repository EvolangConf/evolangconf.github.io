library(lmerTest)
library(car)

# Experiment 1: Semantic relatedness decisions --------------

Exp1.all <- read.csv("Exp1.csv",T)

# Exclude participants with accuracy below 75%
exclude <- aggregate(Correct~Subject,Exp1.all,mean)
colnames(exclude) <- c("Subject","Accuracy")
Exp1a <- merge(Exp1.all,exclude,by="Subject")
Exp1b <- subset(Exp1a,Accuracy > .75)

# Remove fillers (keep semantically unrelated cue-target pairs only)
Exp1c <- subset(Exp1b,ANSWER=="NO")

# Remove fast guesses
Exp1 <- subset(Exp1c,RT>=200)

# Sum code condition (-1,1) with pseudo-phonesthemic targets as the positive value
Exp1$Condition <- factor(Exp1$Condition, levels=c("Ph","Ctrl"))
contrasts(Exp1$Condition) <- contr.Sum(levels(Exp1$Condition))
contrasts(Exp1$Condition)

# For RT, correct responses only
Exp1.RT <- subset(Exp1,Correct==1)

## Experiment 1 RT --------------

# forward model comparison
E1a <- lmer(RT~Condition+(1|Subject)+(1|Item),data=Exp1.RT,REML=F,control=lmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
E1b <- lmer(RT~Condition+(Condition+1|Subject)+(1|Item),data=Exp1.RT,REML=F,control=lmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
E1c <- lmer(RT~Condition+(1|Subject)+(Condition+1|Item),data=Exp1.RT,REML=F,control=lmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))

# alpha = 0.2
anova(E1a,E1b) # p = 0.1049
anova(E1a,E1c) # p = 0.241

summary(E1b)
# (Intercept)      775.179     16.212  60.143  47.814  < 2e-16 ***
# Condition[S.Ph]   13.592      3.791 324.819   3.586 0.000388 ***


## Experiment 1 accuracy --------------------

# forward model comparison
E1accA <- glmer(Correct~Condition+(1|Subject)+(1|Item),data=Exp1,family=binomial,control=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
E1accB <- glmer(Correct~Condition+(Condition+1|Subject)+(1|Item),Exp1,family=binomial,control=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
E1accC <- glmer(Correct~Condition+(1|Subject)+(Condition+1|Item),data=Exp1,family=binomial,control=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))

# alpha = 0.2
anova(E1accA,E1accB) # p = 0.09008
anova(E1accA,E1accC) # p = 0.003655

E1acc <- glmer(Correct~Condition+(Condition+1|Subject)+(Condition+1|Item),data=Exp1,family=binomial,control=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))

summary(E1acc)
# (Intercept)       2.9521     0.1705  17.312   <2e-16 ***
# Condition[S.Ph]  -0.1609     0.1502  -1.071    0.284 


# Experiment 2: Visually degraded lexical decisions ------------------

Exp2.all <- read.csv("Exp2.csv",T)

# Exclude participants with accuracy below 75%
exclude <- aggregate(Exp2.all$Correct,list(Exp2.all$Subject),mean)
colnames(exclude) <- c("Subject","Accuracy")
Exp2a <- merge(Exp2.all,exclude,by="Subject")
Exp2b <- subset(Exp2a,Accuracy > .75)

# Remove fillers (remove non-words)
Exp2c <- subset(Exp2b,ANSWER=="YES")

# Remove fast guesses
Exp2 <- subset(Exp2c,RT>200)

# Sum code presentation and word type (-1,1) 
# with degraded presentation and phonesthemic targets as the positive values
Exp2$Presentation <- factor(Exp2$Presentation,levels=c("Degraded","Clear"))
Exp2$WordType <- factor(Exp2$WordType,levels=c("Ph","Ctrl"))
contrasts(Exp2$Presentation) <- contr.Sum(levels(Exp2$Presentation))
contrasts(Exp2$Presentation)
contrasts(Exp2$WordType) <- contr.Sum(levels(Exp2$WordType))
contrasts(Exp2$WordType)

# For RT, correct responses only
Exp2.RT <- subset(Exp2,Correct==1)


## Experiment 2 RT -------------------

# Forward model comparison
E2a <- lmer(RT~Presentation*WordType+(1|Subject)+(1|Item),data=Exp2.RT,REML=F,control=lmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
E2b <- lmer(RT~Presentation*WordType+(Presentation+1|Subject)+(1|Item),data=Exp2.RT,REML=F,control=lmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
E2c <- lmer(RT~Presentation*WordType+(1|Subject)+(Presentation+1|Item),data=Exp2.RT,REML=F,control=lmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
E2d <- lmer(RT~Presentation*WordType+(WordType+1|Subject)+(1|Item),data=Exp2.RT,REML=F,control=lmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
E2e <- lmer(RT~Presentation*WordType+(1|Subject)+(WordType+1|Item),data=Exp2.RT,REML=F,control=lmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
# Model failed to converge with 1 negative eigenvalue
E2f <- lmer(RT~Presentation*WordType+(WordType*Presentation+1|Subject)+(1|Item),data=Exp2.RT,REML=F,control=lmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
# Model failed to converge with 1 negative eigenvalue
E2g <- lmer(RT~Presentation*WordType+(1|Subject)+(WordType*Presentation+1|Item),data=Exp2.RT,REML=F,control=lmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
# Model failed to converge with 1 negative eigenvalue 

# alpha = 0.2
anova(E2a,E2b) # p = 4.768e-06
anova(E2a,E2c) # p = 0.00279
anova(E2a,E2d) # p = 0.8511

E2 <- lmer(RT~Presentation*WordType+(Presentation+1|Subject)+(Presentation+1|Item),data=Exp2.RT,REML=F,control=lmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
summary(E2)
# (Intercept)                              710.137     14.235  65.408  49.888  < 2e-16 ***
# Presentation[S.Degraded]                  69.360      4.028  65.769  17.219  < 2e-16 ***
# WordType[S.Ph]                           -11.524      4.177 185.587  -2.759  0.00638 ** 
# Presentation[S.Degraded]:WordType[S.Ph]   -6.710      2.898 185.431  -2.315  0.02170 *  


## Experiment 2 accuracy --------------------

# forward model comparison
E2accA <- glmer(Correct~Presentation*WordType+(1|Subject)+(1|Item),data=Exp2,family=binomial,control=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
E2accB <- glmer(Correct~Presentation*WordType+(Presentation+1|Subject)+(1|Item),data=Exp2,family=binomial,control=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
E2accC <- glmer(Correct~Presentation*WordType+(1|Subject)+(Presentation+1|Item),data=Exp2,family=binomial,control=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
E2accD <- glmer(Correct~Presentation*WordType+(WordType+1|Subject)+(1|Item),data=Exp2,family=binomial,control=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
E2accE <- glmer(Correct~Presentation*WordType+(1|Subject)+(WordType+1|Item),data=Exp2,family=binomial,control=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
E2accF <- glmer(Correct~Presentation*WordType+(WordType*Presentation+1|Subject)+(1|Item),data=Exp2,family=binomial,control=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))
E2accG <- glmer(Correct~Presentation*WordType+(1|Subject)+(WordType*Presentation+1|Item),data=Exp2,family=binomial,control=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=1e6)))

# alpha = 0.2
anova(E2accA,E2accB) # p = 0.2009
anova(E2accA,E2accC) # p = 0.05904 
anova(E2accA,E2accD) # p = 0.4067
anova(E2accA,E2accE) # p = 0.3867
anova(E2accA,E2accF) # p = 0.5392
anova(E2accA,E2accG) # p = 0.4721

summary(E2accC)
# (Intercept)                              2.94841    0.17452  16.895  < 2e-16 ***
# Presentation[S.Degraded]                -0.47152    0.11817  -3.990  6.6e-05 ***
# WordType[S.Ph]                           0.44231    0.13450   3.288  0.00101 ** 
# Presentation[S.Degraded]:WordType[S.Ph] -0.04115    0.07492  -0.549  0.58280  
