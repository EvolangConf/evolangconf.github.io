These are the supplementary materials for the Evolang (2020) abstract ``Modelling the role of other-initiated repair in facilitating the emergence of compositionality" by Marieke Woensdregt and Mark Dingemanse.

These supplementary materials contain:

1. A jupyter notebook explaining the motivation for this model, and the design decisions we made (evolution_compositionality_under_noise; available in .ipynb, .html and .pdf formats).
2. The Python code we used to run the simulations for this abstract (evolution_compositionality_under_noise_for_evolang.py)
3. A pdf document which summarises the model and shows simulation results for a range of different parameter settings (summary_simulation_results.pdf)


All code needed to run these simulations is contained in a single python script called evolution_compositionality_under_noise_for_evolang.py

This script expects several input arguments. In order to run it:
1. make sure you have Python 3 installed
2. open a terminal window
3. navigate to the folder where you have saved the evolution_compositionality_under_noise_for_evolang.py script
4. Type the following:
python3 evolution_compositionality_under_noise_for_evolang.py [BOTTLENECK] [LEARNABILITY PRESSURE] [NOISE PROBABILITY] [MUTUAL UNDERSTANDING PRESSURE] [MINIMAL EFFORT PRESSURE]

The variables in square brackets above specify the parameter settings; these expect either numbers or boolean variables (i.e. True or False). 

To give an example, running the following line:

python3 evolution_compositionality_under_noise_for_evolang.py 20 False 0.6 True True

will run a simulation where:
- the transmission bottleneck is 20 (i.e. learners receive 20 data points)
- the pressure for learnability is turned off (i.e. learners do not have a learning bias in favour of simpler/more compressible languages)
- the probability of noise obscuring a signal is 0.6
- the pressure for mutual understaning is turned on
- the pressure for minimal effort is turned on


We refer the reader to the GitHub repository:
https://github.com/marieke-woensdregt/repair_compositionality
For updates and further extensions of the code.